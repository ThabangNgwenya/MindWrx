<?php

session_start();


$webmaster_email = "Thabang.ngwenya@wesbank.co.za" ;

$feedback_page = "checkout.html" ;

$thankyou_page = "thank_you.html" ;


$name = $_REQUEST['name'] ;

$surname = $_REQUEST['surname'] ;

$email_address = $_REQUEST['email_address'] ;

$cell = $_REQUEST['cell'] ;

$card = $_REQUEST['card'] ;

$area1 = $_REQUEST['area1'] ;
$area2 = $_REQUEST['area2'] ;
$area3 = $_REQUEST['area3'] ;

$msg = 
"First Name: " . $name . "\r\n" . 
"Last Name: " . $surname . "\r\n" . 
"Email: " . $email_address ."\r\n" . 
"Cell Number: " . $cell ."\r\n" .
"Province: " . $area1 . "\r\n" .
"City: " . $area2 . "\r\n" . 
"Street: " . $area3 . "\r\n" . 
"Card Num: " . $card  ;


function isInjected($str) {
	$injections = array('(\n+)',
	'(\r+)',
	'(\t+)',
	'(%0A+)',
	'(%0D+)',
	'(%08+)',
	'(%09+)'
	);
	$inject = join('|', $injections);
	$inject = "/$inject/i";
	if(preg_match($inject,$str)) {
		return true;
	}
	else {
		return false;
	}
}
	mail( "$webmaster_email", "New Order From TBeatz Studio Equipment", $msg );
 
    $from = "TBeatz Studio Equipment";
    $to = $email_address ;
    $subject = "Recent Order" ;
    $message = "Greetings,  
    Thank You for shopping with us. Your order has been placed and will be delivered in no longer than 7 days. " ;
    $headers = "From:" . $from;
    mail($to,$subject,$message, $headers);

	header( "Location: $thankyou_page" );

?>